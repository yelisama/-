import json
import os
import random
import asyncio
import re
from datetime import datetime, timezone, timedelta
from collections import Counter
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Context, Star, register
from astrbot.api import logger

# ==================== 路径配置 ====================
DATA_DIR = os.path.join("data")
DATA_FILE = os.path.join(DATA_DIR, "scratchcard_data.json")
OLD_DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data.json")
FEED_KNOWLEDGE_FILE = os.path.join(DATA_DIR, "feed_knowledge.json")
CST = timezone(timedelta(hours=8))

# ==================== 游戏数值常量 ====================
INITIAL_COINS = 200
DRAW_COST = 10
WISH_COST = 500
DAILY_LIMIT = 10
PITY_THRESHOLD = 90
FEED_LIMIT = 3

# 奖池配置
PRIZE_POOL = [
    {"name": "★金光闪闪大奖★", "prob": 0.01, "range": (80, 150)},
    {"name": "二等奖", "prob": 0.05, "range": (30, 50)},
    {"name": "三等奖", "prob": 0.14, "range": (15, 25)},
    {"name": "四等奖", "prob": 0.30, "range": (8, 14)},
    {"name": "参与奖", "prob": 0.50, "range": (1, 7)},
]

# 收藏品（共10个，分三档稀有度）
COLLECTIBLES = [
    {"name": "穗织的神木叶片", "rarity": "⭐"},
    {"name": "五百年前的铜钱", "rarity": "⭐"},
    {"name": "神社的樱花御守", "rarity": "⭐"},
    {"name": "金色小铃铛", "rarity": "⭐"},
    {"name": "丛雨丸的迷你刀鞘", "rarity": "⭐⭐"},
    {"name": "丛雨的睡衣蝴蝶结", "rarity": "⭐⭐"},
    {"name": "穗织温泉的入浴券", "rarity": "⭐⭐"},
    {"name": "丛雨大人的手写签", "rarity": "⭐⭐⭐"},
    {"name": "丛雨丸的刀鍔碎片", "rarity": "⭐⭐⭐"},
    {"name": "幻之丛雨水晶", "rarity": "⭐⭐⭐"},
]

# 稀有度权重
RARITY_WEIGHTS = {
    "⭐⭐⭐": 1,
    "⭐⭐": 3,
    "⭐": 6,
}

# 参与奖额外掉落收藏品的概率
COLLECTIBLE_BONUS_RATE = 0.005

# 投喂金币上下限
FEED_GOLD_MAX = 30
FEED_GOLD_MIN = -30

# LLM 调用超时（秒）
LLM_TIMEOUT = 15

# 数据并发锁（保护文件读写，防止并发覆盖）
_data_lock = asyncio.Lock()


# ==================== 数据持久化 ====================
def load_data():
    """读取用户数据，支持自动迁移旧数据。
    
    注意：此方法本身不加锁，调用方应在外层使用 _data_lock。
    """
    os.makedirs(DATA_DIR, exist_ok=True)

    # 自动迁移旧数据
    if not os.path.exists(DATA_FILE) and os.path.exists(OLD_DATA_FILE):
        try:
            with open(OLD_DATA_FILE, "r", encoding="utf-8") as f:
                old_data = json.load(f)
            with open(DATA_FILE, "w", encoding="utf-8") as f:
                json.dump(old_data, f, ensure_ascii=False, indent=2)
            logger.info(f"旧数据已自动迁移: {OLD_DATA_FILE} → {DATA_FILE}")
        except Exception as e:
            logger.error(f"旧数据迁移失败: {e}")

    if not os.path.exists(DATA_FILE):
        return {}

    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError, UnicodeDecodeError) as e:
        logger.error(f"数据文件读取失败，将使用空数据。错误: {e}")
        return {}


def save_data(data):
    """保存用户数据。
    
    注意：此方法本身不加锁，调用方应在外层使用 _data_lock。
    """
    os.makedirs(DATA_DIR, exist_ok=True)
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except (OSError, PermissionError) as e:
        logger.error(f"保存数据失败: {e}")


def load_feed_knowledge():
    """读取供奉知识库，返回 {物品名: 金币值}"""
    if not os.path.exists(FEED_KNOWLEDGE_FILE):
        return {}
    try:
        with open(FEED_KNOWLEDGE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError, UnicodeDecodeError) as e:
        logger.error(f"供奉知识库读取失败: {e}")
        return {}


def save_feed_knowledge(knowledge: dict):
    """保存供奉知识库"""
    os.makedirs(DATA_DIR, exist_ok=True)
    try:
        with open(FEED_KNOWLEDGE_FILE, "w", encoding="utf-8") as f:
            json.dump(knowledge, f, ensure_ascii=False, indent=2)
    except (OSError, PermissionError) as e:
        logger.error(f"保存供奉知识库失败: {e}")


# ==================== 用户数据工具 ====================
def get_user(data, user_id, initial_coins=INITIAL_COINS):
    """获取用户数据，如果不存在则用默认值初始化。"""
    if user_id not in data:
        data[user_id] = {
            "coins": initial_coins,
            "wishes": [],
            "daily_date": "",
            "daily_draws": 0,
            "total_draws": 0,
            "collection": [],
            "feed_date": "",
            "feed_count": 0,
        }
    return data[user_id]


def reset_daily_if_new_day(user):
    """检查是否跨天，如果是则重置每日抽卡次数与投喂次数。"""
    today = datetime.now(CST).strftime("%Y-%m-%d")
    if user.get("daily_date") != today:
        user["daily_date"] = today
        user["daily_draws"] = 0
    if user.get("feed_date") != today:
        user["feed_date"] = today
        user["feed_count"] = 0


def do_draw():
    """执行一次抽奖，返回 (奖项名, 金币数)"""
    r = random.random()
    cumulative = 0
    for prize in PRIZE_POOL:
        cumulative += prize["prob"]
        if r <= cumulative:
            low, high = prize["range"]
            coins = random.randint(low, high)
            return prize["name"], coins
    # 兜底
    low, high = PRIZE_POOL[-1]["range"]
    return PRIZE_POOL[-1]["name"], random.randint(low, high)


def get_random_collectible(available_pool=None):
    """按稀有度权重随机出一个收藏品。
    
    Args:
        available_pool: 可选的候选列表，默认使用全局 COLLECTIBLES
    """
    pool = available_pool or COLLECTIBLES
    weights = [RARITY_WEIGHTS.get(c["rarity"], 1) for c in pool]
    return random.choices(pool, weights=weights, k=1)[0]


# ==================== 插件主类 ====================
@register("刮刮乐", "congyusama", "夜璃的神社刮刮乐！10金币一次，每日抽卡上限，保底收藏品", "1.2.0")
class ScratchCardPlugin(Star):
    def __init__(self, context: Context, config=None):
        super().__init__(context)
        cfg = config or {}
        self.draw_cost = cfg.get("draw_cost", DRAW_COST)
        self.daily_limit = cfg.get("daily_limit", DAILY_LIMIT)
        self.wish_cost = cfg.get("wish_cost", WISH_COST)
        self.pity_threshold = cfg.get("pity_threshold", PITY_THRESHOLD)
        self.initial_coins = cfg.get("initial_coins", INITIAL_COINS)
        self.feed_enabled = cfg.get("feed_enabled", True)
        # 管理员从配置读取，支持字符串或列表
        admin_cfg = cfg.get("admin_users", [])
        if isinstance(admin_cfg, str):
            self.admin_users = [admin_cfg.strip()]
        elif isinstance(admin_cfg, list):
            self.admin_users = [str(u).strip() for u in admin_cfg]
        else:
            self.admin_users = []

        # 注册官方插件页面 API
        self._register_page_api()

    def _register_page_api(self) -> None:
        """按需注册官方插件页面 API。"""
        if not hasattr(self.context, "register_web_api"):
            return
        try:
            from .page_api import PluginPageApi
            self.page_api = PluginPageApi(self)
            self.page_api.register_routes()
            logger.info("刮刮乐页面 API 已注册")
        except Exception as exc:
            logger.warning(f"刮刮乐页面 API 注册失败: {exc}")

    # ==================== 内部辅助方法 ====================
    def _check_daily_limit(self, user, user_name):
        """检查今日抽卡次数是否已达上限。
        
        返回 None 表示通过，否则返回错误消息。
        内部会自动重置跨天数据。
        """
        reset_daily_if_new_day(user)
        if user["daily_draws"] >= self.daily_limit:
            return (
                f"{user_name}，汝今天的{self.daily_limit}次抽卡额度已经用完啦，明天再来吧～"
            )
        return None

    def _check_coins(self, user, user_name, cost):
        """检查余额是否足够支付指定费用。
        
        返回 None 表示通过，否则返回错误消息。
        """
        if user["coins"] < cost:
            return (
                f"{user_name}，汝的金币不足啦！当前金币：{user['coins']}，"
                f"需要{cost}金币的说。"
            )
        return None

    def _resolve_collectible(self, user):
        """从用户未收集的收藏品中按权重随机选一个。
        
        若已全收集，则从全部收藏品中随机（允许重复）。
        """
        owned = set(user.get("collection", []))
        available = [c for c in COLLECTIBLES if c["name"] not in owned]
        if not available:
            available = COLLECTIBLES  # 全图鉴了，出啥都行
        return get_random_collectible(available)

    def _do_single_draw(self, user):
        """执行一次抽奖，返回 (prize_name, prize_coins, collectible_or_None, is_pity)
        
        is_pity: True=保底触发, False=欧皇额外掉落, None=未获得收藏品
        """
        prize_name, prize_coins = do_draw()
        user["total_draws"] = user.get("total_draws", 0) + 1

        collectible = None
        is_pity = None

        # 硬保底判定
        if user["total_draws"] >= self.pity_threshold:
            user["total_draws"] = 0
            collectible = self._resolve_collectible(user)
            is_pity = True
        # 非保底时，参与奖有概率额外掉落收藏品
        elif prize_name == "参与奖" and random.random() < COLLECTIBLE_BONUS_RATE:
            collectible = self._resolve_collectible(user)
            is_pity = False

        user["coins"] += prize_coins
        return prize_name, prize_coins, collectible, is_pity

    def _build_draw_result_msg(self, user_name, user, prize_name, prize_coins, 
                               collectible, is_pity, draw_count=1):
        """构建单抽/十连的公共结果消息。"""
        msg = f"🎫 {user_name} 刮开了一张刮刮乐！\n获得：{prize_name} → +{prize_coins} 金币"

        if prize_name == "★金光闪闪大奖★":
            msg += "\n狗修金运气也太好了吧，夜璃大人都惊呆了的说！"

        if collectible:
            if is_pity:
                msg += (
                    f"\n💎 保底触发！获得收藏品："
                    f"【{collectible['name']}】{collectible['rarity']}"
                )
            else:
                msg += (
                    f"\n✨ 欧皇降临！非保底居然出了收藏品："
                    f"【{collectible['name']}】{collectible['rarity']}，"
                    f"汝的运气简直闪瞎吾辈的说！"
                )

        msg += (
            f"\n余额：{user['coins']} 金币 | "
            f"今日已抽：{user['daily_draws']}/{self.daily_limit} | "
            f"距保底：{self.pity_threshold - user['total_draws']}抽"
        )
        return msg

    # ==================== 指令：刮刮乐 ====================
    @filter.command("刮刮乐")
    async def scratch_card(self, event: AstrMessageEvent):
        user_id = event.get_sender_id()
        user_name = event.get_sender_name()

        async with _data_lock:
            data = load_data()
            user = get_user(data, user_id, self.initial_coins)

            limit_err = self._check_daily_limit(user, user_name)
            if limit_err:
                yield event.plain_result(limit_err)
                event.stop_event()
                return

            coin_err = self._check_coins(user, user_name, self.draw_cost)
            if coin_err:
                yield event.plain_result(coin_err)
                event.stop_event()
                return

            user["coins"] -= self.draw_cost
            user["daily_draws"] += 1
            prize_name, prize_coins, collectible, is_pity = self._do_single_draw(user)

            if collectible:
                user.setdefault("collection", []).append(collectible["name"])

            save_data(data)

        msg = self._build_draw_result_msg(
            user_name, user, prize_name, prize_coins, collectible, is_pity
        )
        yield event.plain_result(msg)
        event.stop_event()

    # ==================== 指令：十连 ====================
    @filter.command("十连", alias={"十连刮刮乐"})
    async def scratch_ten(self, event: AstrMessageEvent):
        user_id = event.get_sender_id()
        user_name = event.get_sender_name()
        cost = self.draw_cost * 10

        async with _data_lock:
            data = load_data()
            user = get_user(data, user_id, self.initial_coins)

            limit_err = self._check_daily_limit(user, user_name)
            if limit_err:
                yield event.plain_result(limit_err)
                event.stop_event()
                return

            # 检查十连后是否超过每日上限
            if user["daily_draws"] + 10 > self.daily_limit:
                remaining = self.daily_limit - user["daily_draws"]
                yield event.plain_result(
                    f"{user_name}，十连需要10次额度，"
                    f"汝今天只剩{remaining}次了，单抽将就一下吧～"
                )
                event.stop_event()
                return

            coin_err = self._check_coins(user, user_name, cost)
            if coin_err:
                yield event.plain_result(coin_err)
                event.stop_event()
                return

            user["coins"] -= cost
            user["daily_draws"] += 10

            results = []
            total_gain = 0
            collectibles_got = []

            for _ in range(10):
                prize_name, prize_coins, collectible, is_pity = self._do_single_draw(user)
                results.append((prize_name, prize_coins))
                total_gain += prize_coins
                if collectible:
                    collectibles_got.append((collectible, is_pity))

            if collectibles_got:
                for c, _ in collectibles_got:
                    user.setdefault("collection", []).append(c["name"])

            save_data(data)

        # 构建消息（锁外执行，减少锁持有时间）
        lines = [f"🎫 {user_name} 刮开了十张刮刮乐！"]
        for i, (name, coins) in enumerate(results, 1):
            lines.append(f"  {i}. {name} +{coins}")
        lines.append(f"总计获得：{total_gain} 金币")

        flash_count = sum(1 for name, _ in results if name == "★金光闪闪大奖★")
        if flash_count > 0:
            lines.append(f"夜璃震惊！竟然出了{flash_count}个金光闪闪大奖的说！")

        if collectibles_got:
            for c, was_pity in collectibles_got:
                if was_pity:
                    lines.append(
                        f"💎 保底触发！获得收藏品："
                        f"【{c['name']}】{c['rarity']}"
                    )
                else:
                    lines.append(
                        f"✨ 欧皇降临！非保底居然出了收藏品："
                        f"【{c['name']}】{c['rarity']}，"
                        f"汝的运气简直闪瞎吾辈的说！"
                    )

        lines.append(
            f"余额：{user['coins']} 金币 | "
            f"今日已抽：{user['daily_draws']}/{self.daily_limit} | "
            f"距保底：{self.pity_threshold - user['total_draws']}抽"
        )

        yield event.plain_result("\n".join(lines))
        event.stop_event()

    # ==================== 指令：许愿 ====================
    @filter.command("许愿")
    async def make_wish(self, event: AstrMessageEvent):
        user_id = event.get_sender_id()
        user_name = event.get_sender_name()

        message_str = event.message_str.strip()
        wish_content = message_str
        for prefix in ["/许愿", "许愿"]:
            if wish_content.startswith(prefix):
                wish_content = wish_content[len(prefix):].strip()
                break

        if not wish_content:
            yield event.plain_result(
                f"{user_name}，汝还没告诉吾辈要许什么愿呢！"
                f"比如「许愿 想要夜璃的抱抱」这样～"
            )
            event.stop_event()
            return

        async with _data_lock:
            data = load_data()
            user = get_user(data, user_id, self.initial_coins)

            coin_err = self._check_coins(user, user_name, self.wish_cost)
            if coin_err:
                yield event.plain_result(
                    f"{user_name}，许愿需要{self.wish_cost}金币哦！"
                    f"汝当前只有{user['coins']}金币，"
                    f"还差{self.wish_cost - user['coins']}金币的说。"
                )
                event.stop_event()
                return

            user["coins"] -= self.wish_cost
            today = datetime.now(CST).strftime("%Y-%m-%d")
            user["wishes"].append({"content": wish_content, "date": today})
            save_data(data)

        yield event.plain_result(
            f"✨ {user_name} 花费{self.wish_cost}金币向神社许愿：\n"
            f"「{wish_content}」\n"
            f"神社收到啦，愿望已挂上许愿树～剩余金币：{user['coins']}"
        )
        event.stop_event()

    # ==================== 指令：金币 ====================
    @filter.command("金币")
    async def check_coins(self, event: AstrMessageEvent):
        user_id = event.get_sender_id()
        user_name = event.get_sender_name()

        async with _data_lock:
            data = load_data()
            user = get_user(data, user_id, self.initial_coins)

        yield event.plain_result(f"💰 {user_name} 当前金币：{user['coins']}")
        event.stop_event()

    # ==================== 指令：许愿树 ====================
    @filter.command("许愿树")
    async def wish_tree(self, event: AstrMessageEvent):
        async with _data_lock:
            data = load_data()
            all_wishes = []
            for uid, u in data.items():
                for w in u.get("wishes", []):
                    # 兼容旧格式（纯字符串）和新格式（{content, date}）
                    if isinstance(w, str):
                        all_wishes.append({"content": w, "date": "未知"})
                    else:
                        all_wishes.append(w)
            if not all_wishes:
                yield event.plain_result("🌳 许愿树上还没有挂任何愿望呢～")
                event.stop_event()
                return
            # 按日期排序
            all_wishes.sort(key=lambda x: x["date"], reverse=True)
            lines = ["🌳 丛雨神社 · 许愿树"]
            for i, w in enumerate(all_wishes[:50], 1):
                lines.append(f"  {i}. {w['content']}（{w['date']}）")
            if len(all_wishes) > 50:
                lines.append(f"  ...还有 {len(all_wishes)-50} 条愿望挂在树上")

        yield event.plain_result("\n".join(lines))
        event.stop_event()

    # ==================== 指令：刮刮乐帮助 ====================
    @filter.command("刮刮乐帮助")
    async def scratch_help(self, event: AstrMessageEvent):
        help_text = (
            "🎴 丛雨神社刮刮乐 — 帮助\n"
            "\n"
            "📋 指令：\n"
            "/刮刮乐 — 单抽一次（10金币）\n"
            "/十连 — 十连抽（100金币）\n"
            "/金币 — 查看余额\n"
            "/收藏品 — 查看收藏品柜\n"
            "/投喂 <物品> — 投喂吾辈换金币（日限3次）\n"
            "/许愿 <内容> — 花500金币挂愿望上许愿树\n"
            "/许愿树 — 查看所有人的匿名愿望\n"
            "\n"
            "🎯 奖项概率：\n"
            "金光闪闪 1%(80~150) | 二等奖 5%(30~50)\n"
            "三等奖 14%(15~25) | 四等奖 30%(8~14)\n"
            "参与奖 50%(1~7)\n"
            "\n"
            "💎 收藏品：10件，90抽保底，参与奖0.5%欧皇触发\n"
            "⏰ 每日抽卡10次上限，凌晨0点重置\n"
            "💰 新人初始200金币"
        )
        yield event.plain_result(help_text)
        event.stop_event()

    # ==================== 指令：收藏品 ====================
    @filter.command("收藏品")
    async def show_collection(self, event: AstrMessageEvent):
        user_id = event.get_sender_id()
        user_name = event.get_sender_name()

        async with _data_lock:
            data = load_data()
            user = get_user(data, user_id, self.initial_coins)
            collection = user.get("collection", [])

            if not collection:
                yield event.plain_result(
                    f"{user_name} 还没有任何收藏品哦～"
                    f"多抽刮刮乐，{self.pity_threshold}抽保底必出！"
                )
                event.stop_event()
                return

            counts = Counter(collection)

        lines = [f"💎 {user_name} 的收藏品柜："]
        for item in COLLECTIBLES:
            name = item["name"]
            if name in counts:
                lines.append(f"  {item['rarity']} {name} ×{counts[name]}")

        lines.append(f"共 {len(collection)} 件收藏品")
        yield event.plain_result("\n".join(lines))
        event.stop_event()

    # ==================== 指令：投喂 ====================
    @filter.command("投喂")
    async def feed(self, event: AstrMessageEvent):
        if not self.feed_enabled:
            yield event.plain_result(
                "🍡 投喂功能目前暂停调试中，狗修金正在优化，稍后再来投喂吾辈吧～"
            )
            event.stop_event()
            return

        user_id = event.get_sender_id()
        user_name = event.get_sender_name()

        message_str = event.message_str.strip()
        item = message_str
        for prefix in ["/投喂", "投喂"]:
            if item.startswith(prefix):
                item = item[len(prefix):].strip()
                break

        if not item:
            yield event.plain_result(
                f"{user_name}，汝要投喂吾辈什么呀？比如「投喂 团子」这样～"
            )
            event.stop_event()
            return

        # 限制单次投喂物品名称长度，防止滥用
        if len(item) > 50:
            yield event.plain_result(
                f"{user_name}，这名字也太长了吧，吾辈记不住啦！短一点嘛～"
            )
            event.stop_event()
            return

        async with _data_lock:
            data = load_data()
            user = get_user(data, user_id, self.initial_coins)

            # 检查每日投喂次数
            reset_daily_if_new_day(user)
            if user["feed_count"] >= FEED_LIMIT:
                yield event.plain_result(
                    f"{user_name}，今天已经投喂了{FEED_LIMIT}次啦，"
                    f"吾辈吃不下了，明天再来吧～"
                )
                event.stop_event()
                return

            # 神社判定给多少金币
            gold, source = self._judge_feed(item)

            # 如果是新供奉，调用LLM智能裁定
            if source == "fallback_new":
                # 锁内调用 LLM 会阻塞其他用户，先释放锁，裁定后再加锁
                pass  # 占位，实际逻辑在下面

        if source == "fallback_new":
            gold = await self._llm_judge_feed(event, item)
            # 自动记入知识库
            knowledge = load_feed_knowledge()
            knowledge_key = item.lower().strip()
            # 只记录合理范围内的值，防止异常值污染知识库
            if FEED_GOLD_MIN <= gold <= FEED_GOLD_MAX:
                knowledge[knowledge_key] = gold
                save_feed_knowledge(knowledge)

        # 重新加锁写入金币变动
        async with _data_lock:
            data = load_data()
            user = get_user(data, user_id, self.initial_coins)
            # 防止余额被扣成负数
            if gold < 0 and user["coins"] + gold < 0:
                gold = -user["coins"]  # 最多扣到 0

            user["coins"] += gold
            user["feed_count"] += 1
            save_data(data)

        emoji, reaction, feeling = self._get_feed_reaction(item, gold)
        sign = "+" if gold >= 0 else ""

        msg = (
            f"{emoji} {user_name} 供奉了「{item}」！\n"
            f"夜璃{reaction}：{feeling}\n"
            f"{sign}{gold} 金币！剩余金币：{user['coins']} 金币\n"
            f"今日投喂：{user['feed_count']}/{FEED_LIMIT}"
        )

        if source == "fallback_new":
            msg += (
                f"\n📖 夜璃已经把「{item}」记在供奉名录上了，"
                f"下次再有人供奉就知道给多少啦～"
            )

        yield event.plain_result(msg)
        event.stop_event()

    def _judge_feed(self, item: str) -> tuple:
        """判定投喂物品的金币值。
        
        返回 (gold, source)，source 为 "knowledge" / "keywords" / "fallback_new"
        """
        s = item.lower().strip()

        # 0. 查供奉知识库（之前学过的）
        knowledge = load_feed_knowledge()
        if s in knowledge:
            return (knowledge[s], "knowledge")

        # ----- 喜好词库 -----
        likes = [
            (["团子", "丸子", "dango", "糰子", "お団子"], (22, 30)),
            (["布丁", "布甸", "pudding", "プリン"], (18, 26)),
            (["草莓", "いちご", "strawberry", "草莓大福"], (16, 25)),
            (["甜", "糖", "蛋糕", "甜品", "糖果", "蜜", "巧克力", "马卡龙"], (10, 25)),
            (["冰淇淋", "雪糕", "冰激凌", "刨冰", "かき氷"], (12, 22)),
            (["糯米", "年糕", "麻薯", "もち", "大福"], (12, 22)),
            (["果汁", "奶茶", "牛奶", "可可", "抹茶"], (6, 18)),
            (["肉包", "小笼包", "饺子", "烧卖"], (6, 16)),
            (["烤肉", "烧肉", "牛排", "炸鸡"], (6, 16)),
            (["夜璃", "丛雨丸", "巫女", "神社"], (8, 20)),
            (["夸奖", "好看", "可爱", "厉害", "棒", "聪明", "漂亮", "赞美"], (6, 16)),
        ]

        dislikes = [
            (["鬼", "幽灵", "妖怪", "恐怖", "吓人", "ghost", "spooky"], (-30, -20)),
            (["苦瓜", "苦", "药", "中药", "黄莲", "苦参"], (-22, -12)),
            (["辣", "辣椒", "芥末", "wasabi", "辣椒精"], (-16, -6)),
            (["虫子", "虫", "蜘蛛", "蟑螂", "蜈蚣"], (-22, -12)),
            (["过期", "馊", "坏掉", "烂", "发霉"], (-16, -8)),
            (["大蒜", "蒜", "洋葱", "大葱", "韭菜"], (-12, -4)),
            (["骂", "讨厌", "滚", "走开", "烦"], (-10, -4)),
        ]

        score = 0
        matched_keywords = False

        for keywords, (lo, hi) in likes:
            for kw in keywords:
                if kw in s:
                    score += random.randint(lo, hi)
                    matched_keywords = True
                    break

        for keywords, (lo, hi) in dislikes:
            for kw in keywords:
                if kw in s:
                    score += random.randint(lo, hi)
                    matched_keywords = True
                    break

        if matched_keywords:
            return (max(FEED_GOLD_MIN, min(FEED_GOLD_MAX, score)), "keywords")

        # 没匹配到任何关键词，返回 None 待夜璃（LLM）智能裁定
        return (None, "fallback_new")

    async def _llm_judge_feed(self, event: AstrMessageEvent, item: str) -> int:
        """调用LLM（直调provider，不走pipeline避开RAG）来智能裁定新供奉的金币值"""
        try:
            umo = event.unified_msg_origin
            provider = self.context.get_using_provider(umo)
            if not provider:
                raise Exception("没有找到可用的LLM provider")

            # 对 item 做简单转义，防止 prompt 注入
            safe_item = item.replace("{", "{{").replace("}", "}}")

            prompt = (
                f"我是夜璃，暂代神社的魔女。\n"
                f"有人供奉了「{safe_item}」给我。\n"
                f"我要根据自己的喜好来裁定给多少金币（"
                f"{FEED_GOLD_MIN} 到 {FEED_GOLD_MAX} 之间的整数）：\n"
                f"- 超喜欢的甜食/零食/心意 → +10~+30\n"
                f"- 一般的东西 → -3~+6\n"
                f"- 讨厌的东西（苦的、辣的、虫子、大蒜等） → -20~-5\n"
                f"- 特别害怕的东西（鬼、幽灵等） → -30~-20\n"
                f"只回复一个整数数字，不要任何其他文字。"
            )

            # 添加超时保护
            resp = await asyncio.wait_for(
                provider.text_chat(prompt=prompt),
                timeout=LLM_TIMEOUT
            )
            text = resp.completion_text.strip()
            # 正则兜底：从返回文本中提取第一个整数
            nums = re.findall(r'-?\d+', text)
            if nums:
                gold = int(nums[0])
            else:
                gold = 0
            return max(FEED_GOLD_MIN, min(FEED_GOLD_MAX, gold))
        except asyncio.TimeoutError:
            logger.warning("LLM 裁定供奉超时，使用默认值")
            return random.randint(0, 6)
        except Exception as e:
            logger.warning(f"LLM裁定供奉失败，使用保底值: {e}")
            return random.randint(0, 6)

    def _get_feed_reaction(self, item: str, gold: int):
        """根据投喂物品返回 (emoji, reaction, feeling)"""
        s = item.lower().strip()

        # ----- 特殊互动（非食物类）-----
        specials = {
            "猫": ("🐱", "双眼放光地抱起来一顿猛rua", "好可爱！吾辈也想养一只……唔，不过狗修金会不会吃醋呀？"),
            "猫咪": ("🐱", "双眼放光地抱起来一顿猛rua", "好可爱好可爱！毛茸茸的～吾辈准许汝每天投喂这个！"),
            "小猫": ("🐱", "小心翼翼接过来捧在手心", "喵～咳、咳！吾辈才没有学猫叫！"),
            "狗": ("🐶", "开心地蹲下来摸摸狗头", "汪汪！啊不对，吾辈是刀灵又不是狗！"),
            "小狗": ("🐶", "开心地蹲下来摸摸狗头", "尾巴摇得可欢了，不过吾辈没有尾巴可以摇的说"),
            "蟑螂": ("🪳", "尖叫着把东西扔回汝脸上", "呜哇哇哇！！汝故意的吧！！吾辈跟汝拼了！！"),
            "小强": ("🪳", "脸色发青地原地跳起来", "谁、谁会把这种东西当投喂啊！！扣钱扣钱！！"),
            "虫子": ("🐛", "吓得往后一蹦三尺高", "拿开拿开！吾辈虽然是活了五百年的刀灵但最怕这种东西了！"),
            "蜘蛛": ("🕷️", "尖叫着躲到角落里发抖", "呜……汝是不是想害吾辈做噩梦……"),
            "花": ("🌸", "接过来闻了闻，露出微笑", "唔…虽然不能吃，但香香的，算汝有心了～"),
            "玫瑰": ("🌹", "开心地接过来，然后被刺扎了一下", "好疼！……不过看在好看的份上原谅汝了！"),
            "石头": ("🪨", "一脸无语地看着汝", "汝认真的？这玩意儿能投喂吗？！"),
            "手机": ("📱", "好奇地戳了戳屏幕", "唔…这里面有吾辈的容身之处吗？"),
            "抱枕": ("🫂", "接过来抱了抱", "软软的……不过没有吾辈软！"),
            "钱": ("💰", "眼睛一亮接过来", "诶嘿～财迷魔女上线了！这个投喂吾辈很满意！"),
            "金币": ("🪙", "眼睛一亮接过来", "用金币投喂吾辈，真有你的！"),
        }

        for keyword, (emoji, reaction, feeling) in specials.items():
            if keyword in s:
                return emoji, reaction, feeling

        # ----- 普通食物类，按金币分层 -----
        if gold > 0:
            if gold >= 25:
                return ("🍡", "双眼放光", "超好吃！夜璃感动得要哭了的说！")
            elif gold >= 15:
                return ("🍡", "开心地晃着脑袋", "唔唔，好好吃～夜璃很喜欢这个！")
            elif gold >= 5:
                return ("🍡", "满意地点点头", "还不错啦，吾辈勉为其难收下了～")
            else:
                return ("🍡", "轻轻尝了一口", "嗯，一般般吧～")
        elif gold == 0:
            return ("🍡", "面无表情地嚼了嚼", "嗯……啥味道也没有……")
        else:
            if gold <= -20:
                return ("💀", "脸色发青，差点吐出来", "呜哇！这什么东西！汝是想谋害吾辈吗！")
            elif gold <= -10:
                return ("😖", "皱紧了眉头", "呸呸呸，好难吃……吾辈记住汝了！")
            else:
                return ("😐", "一脸嫌弃", "唔……这味道不太对劲的说……")