"""
刮刮乐 — 官方插件页面 API
提供 WebUI 后台查看插件数据的基础接口
"""

from __future__ import annotations

from astrbot.api import logger

PLUGIN_NAME = "astrbot_plugin_scratchcard"
PAGE_API_PREFIX = f"/{PLUGIN_NAME}/page"


class PluginPageApi:
    """刮刮乐官方插件页面 API。"""

    def __init__(self, plugin) -> None:
        self.plugin = plugin

    def register_routes(self) -> None:
        register = self.plugin.context.register_web_api

        register(
            f"{PAGE_API_PREFIX}/stats",
            self.get_stats,
            ["GET"],
            "刮刮乐 — 整体数据统计",
        )
        register(
            f"{PAGE_API_PREFIX}/top",
            self.get_top_users,
            ["GET"],
            "刮刮乐 — 用户排行",
        )
        register(
            f"{PAGE_API_PREFIX}/wishes",
            self.get_wishes,
            ["GET"],
            "刮刮乐 — 许愿树数据",
        )

    async def get_stats(self):
        """返回插件整体统计数据。"""
        import os, json

        DATA_FILE = os.path.join("data", "scratchcard_data.json")
        if not os.path.exists(DATA_FILE):
            return {"total_users": 0, "total_draws": 0, "total_wishes": 0, "total_collectibles": 0}

        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        total_users = len(data)
        total_draws = sum(u.get("total_draws", 0) + u.get("daily_draws", 0) for u in data.values())
        total_wishes = sum(len(u.get("wishes", [])) for u in data.values())
        total_collectibles = sum(len(u.get("collection", [])) for u in data.values())

        return {
            "total_users": total_users,
            "total_draws": total_draws,
            "total_wishes": total_wishes,
            "total_collectibles": total_collectibles,
        }

    async def get_top_users(self):
        """返回用户排行（按金币）。"""
        import os, json

        DATA_FILE = os.path.join("data", "scratchcard_data.json")
        if not os.path.exists(DATA_FILE):
            return {"users": []}

        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        users = []
        for uid, u in data.items():
            users.append({
                "user_id": uid,
                "coins": u.get("coins", 0),
                "draws": u.get("total_draws", 0),
                "collection_count": len(u.get("collection", [])),
                "wish_count": len(u.get("wishes", [])),
            })

        users.sort(key=lambda x: x["coins"], reverse=True)
        return {"users": users[:50]}

    async def get_wishes(self):
        """返回许愿树数据（匿名）。"""
        import os, json

        DATA_FILE = os.path.join("data", "scratchcard_data.json")
        if not os.path.exists(DATA_FILE):
            return {"wishes": []}

        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        all_wishes = []
        for u in data.values():
            for w in u.get("wishes", []):
                if isinstance(w, str):
                    all_wishes.append({"content": w, "date": "未知"})
                else:
                    all_wishes.append(w)

        all_wishes.sort(key=lambda x: x.get("date", ""), reverse=True)
        return {"wishes": all_wishes[:100], "total": len(all_wishes)}
