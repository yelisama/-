(async function() {
    var bridge = window.AstrBotPluginPage;
    if (!bridge) return;

    function build(p) { return "page/" + String(p).replace(/^\/+/, ""); }

    try {
        var stats = await bridge.apiGet(build("stats"), {});
        document.getElementById('total_users').textContent = stats.total_users || 0;
        document.getElementById('total_draws').textContent = stats.total_draws || 0;
        document.getElementById('total_wishes').textContent = stats.total_wishes || 0;
        document.getElementById('total_collectibles').textContent = stats.total_collectibles || 0;
    } catch(e) { console.error(e); }

    try {
        var top = await bridge.apiGet(build("top"), {});
        var tbody = document.getElementById('top-body');
        if (top.users && top.users.length) {
            top.users.forEach(function(u, i) {
                var tr = document.createElement('tr');
                tr.innerHTML = '<td>'+(i+1)+'</td><td>'+u.user_id+'</td><td style="color:#ffd700">'+u.coins+'</td><td>'+u.draws+'</td><td>'+u.collection_count+'</td>';
                tbody.appendChild(tr);
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#666">暂无数据</td></tr>';
        }
    } catch(e) { console.error(e); }
})();
